var load_url = window.location.pathname
var search_keyword = load_url.split(/[/?#]/)[3]
search_keyword = load_url.replace(/[+]/g, ' ');
var has_button = true;

const iconURL = chrome.runtime.getURL("/images/leadstal.gif");
const play_icon = chrome.runtime.getURL("/images/play.svg");
const stop_icon = chrome.runtime.getURL("/images/stop.svg");
const pause_icon = chrome.runtime.getURL("/images/pause.svg");
const fav_icon = chrome.runtime.getURL("/images/fav.icon");
const titles = []
const backend_url = 'https://leadstal.com'
const frontend_url = 'https://leadstal.com'
//const frontend_url = 'http://localhost:3000'
let Keyword = "You didn't search leads"
let resultUrl = frontend_url



let state = {
	item_position: 0,
	sub_item_position: 0,
	previous_id:-1,
	previous_title: '',
	present_title: '',
	previous_list: 0,
	pause: false,
	stoper: false,
	func: null,
	waiter: null,
	totalLeads: 0,
	ref_str: '',
	previous: null,
	temp: null,
	flag: false,
	start: true,
	data: null,
	scroller: 0
}

// Scrapping Tag list
let search_button = ''
let search_box_input_tag = '#searchboxinput'
let list_tag = ''
let sub_list_tag = ''
let list_scroller_tag = ''
let next_button_tag = ''
let previous_list_tag = ''
let back_button_tag = ''
let sub_list_scroller_tag = ''
let back_to_list_button_tag = ''
let waiting_for_list_tag = ''
let title_tag = ''
let sub_title_tag = ''
let category_tag = ''
let infos_selectors_tag = ''
let rating_tag = ''
let total_review_tag = ''
let negative_review_calculator_selectors_tag = ''
let negative_review_calculator_item_tag = ''
let persentage_tag = ''


async function getClassTag(){
	var url = backend_url + '/api/v1/gmap/tag/'
	var post_data = {
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
		},
	}
	await fetch(url, post_data)
		.then((res) => {
			return res.json()
		})
		.then((data) => {
			try{
				tags = data[0]
				search_button = tags.search_button
				search_box_input_tag = tags.search_box_input_tag
				list_tag = tags.list_tag
				sub_list_tag = tags.sub_list_tag
				list_scroller_tag = tags.list_scroller_tag
				next_button_tag = tags.next_button_tag
				previous_list_tag = tags.previous_list_tag
				back_button_tag = tags.back_button_tag
				sub_list_scroller_tag = tags.sub_list_scroller_tag
				back_to_list_button_tag = tags.back_to_list_button_tag
				waiting_for_list_tag = tags.waiting_for_list_tag
				title_tag = tags.title_tag
				sub_title_tag = tags.sub_title_tag
				category_tag = tags.category_tag
				infos_selectors_tag = tags.infos_selectors_tag
				rating_tag = tags.rating_tag
				total_review_tag = tags.total_review_tag
				negative_review_calculator_selectors_tag =
					tags.negative_review_calculator_selectors_tag
				negative_review_calculator_item_tag =
					tags.negative_review_calculator_item_tag
				persentage_tag = tags.persentage_tag
			} catch (error){
			}
		})
		.catch((error) => {
			save_error(JSON.stringify("tag api didn't work "+error, Object.getOwnPropertyNames(error)))
		})
}

chrome.runtime.sendMessage(
	{ command: 'getPage', data: { search_data: search_keyword } },
	(response) => {
		$(document).ready(function () {
			getClassTag();
			collection_button()
			GetSearchValue()
		})
	}
)

function GetSearchValue(){
	if(document.querySelector(search_box_input_tag) !== null){
		var url = window.location.href;

		if(url.match('/search/') !== null){
			has_button = false;
			return document.querySelector('._leadstal__button').style.display = 'flex'
		}
		if(url.match('/search/') === null){
			has_button = true;
			return document.querySelector('._leadstal__button').style.display = 'none'
		}
	}
}

var flag = true;

function Check_leads(){
	let inter = setInterval(function () {
		clearInterval(inter);
		Check_leads();
		var url = window.location.href;

		if(url.match('/search/') !== null && has_button){
			return GetSearchValue();
		}

		if(url.match('/search/') === null && !has_button){
			return GetSearchValue();
		}
	}, 1000)
}

Check_leads();

async function handler(){

	if (state.func === null || state.stoper){
		return;
	}

	if(state.pause){
		await sleep(1000);
		return handler();
	}

	if ( state.waiter !== null)
		return await state.waiter(state.func)

	return state.func()
}

function Reset(){
	state = {
		item_position: 0,
		sub_item_position: 0,
		previous_id:-1,
		previous_title: '',
		present_title: '',
		previous_list: 0,
		pause: false,
		stoper: false,
		func: null,
		waiter: null,
		totalLeads: 0,
		ref_str: '',
		previous: null,
		temp: null,
		flag: false,
		start: true,
		data: null,
		scroller: 0
	}
	return 0;
}

function CloseBtn(){
	document.querySelector('#leadstalShow').style.display = 'none';
	document.querySelector('#ContentBody').style.display = 'none';
	document.querySelector('#leadsCount').innerText = 0;
	document.querySelector('#ResultBody').remove();
	has_button = true;
	Reset()
	return 0;
}

function Play(){
	state.pause = false;

	document.querySelector('#leadstal_play').style.display = 'none';
	document.querySelector('#leadstal_pause').style.display = 'block';
	return 0;
}

function Pause(){
	state.pause = true;
	document.querySelector('#leadstal_pause').style.display = 'none';
	document.querySelector('#leadstal_play').style.display = 'block';
	return 0;
}

function Stop(){
	state.pause = true;
	state.stoper = true;
	state.func = null;
	state.waiter = null;
	document.querySelector('#leadstalShow').appendChild(ResultBody())
	document.getElementById("close").addEventListener("click", CloseBtn)
	document.querySelector('#ContentBody').style.display = 'none';
	document.querySelector('#ResultBody').style.display = 'block';
	localStorage.removeItem('gmap-data');
	return 0;
}

function Start(){
	document.querySelector('#leadstalShow').style.display = 'block';
	document.querySelector('#ContentBody').style.display = 'block';
	document.querySelector('._leadstal__button').style.display = 'none';

	mapScraper();
	return 0;
}


async function mapScraper() {

	try{
		Keyword = document.querySelector(search_box_input_tag).value;
		state.func = leads_parser;
		state.waiter = null;
		let datetime_str = Date.parse(Date().toString())
		state.ref_str = window.btoa(Keyword + datetime_str);
		resultUrl = `${frontend_url}/google-map-result?search=${Keyword}&refer_str=${state.ref_str}`;
		state.sub_item_position = 0;

		localStorage.removeItem('gmap-data');
		await handler();
	} catch (error){
		save_error(JSON.stringify(error, Object.getOwnPropertyNames(error)))
		return;
	}
}


async function get_tag(){
	let list_tags = list_tag.split('|');

	let tag = '';
	tag = list_tags.filter((tag) => {
		let items = document.querySelectorAll(tag.trim());
		if(items.length > 0){
			return tag.trim();
		}
	})

	return tag[0];
}


async function leads_parser() {

	try{
		let tag = await get_tag();
		items = document.querySelectorAll(tag);
		state.item_position = 0;
		if(state.start){
			let button = document.querySelector(search_button);
			button.click();
			state.start = false;
		}

		await data_parser();
	} catch (error){
		state.func = leads_parser;
		state.waiter = waiter;
		console.log(error);

		return await handler();
	}
}


async function data_parser(){
	let tag = await get_tag();
	state.data = await getData();
	if(state.item_position >= state.data.length){
		return Stop();
	}

	try{
		state.scroller += 250;
		$(list_scroller_tag).animate({scrollTop: state.scroller},1000)
		await sleep(1000)
	} catch (error){
		return;
	}
	item = state.data[state.item_position][14];

	let items = document.querySelectorAll(tag);
	items[state.item_position].querySelector('a').focus();
	await sleep(1000);

	let url = items[state.item_position].querySelector('a');
	let google_location = url.getAttribute('href');
	let obj = {
		search_keyword: Keyword,
		title: item[11] || null,
		address: item[39] || null,
		category: item[13] !== null ? item[13][0] : null,
		phone: item[178] !== null ? ( item[178][0] ? item[178][0][3] : null ) : null,
		latitude: item[9] !== null ? item[9][2] : null,
		longitude: item[9] !== null ? item[9][3] : null,
		claim: item[49] === null ? true : false,
		google_location: google_location,
		searchref: {
			ref_str: state.ref_str || null,
		},
		email: {
			email: null,
		},
		website: {
			title: null,
			domain: item[7] !== null ? item[7][1] : null,
		},
		review: {
			total: item[4] !== null ? item[4][8] : null,
			positive: null,
			negative:  null,
			rating: item[4] !== null ? item[4][7] : null,
		},
	}

	post_data(JSON.stringify(obj))
	await sleep(1000);

	state.item_position++;
	state.func = data_parser;
	state.waiter = null;
	return await handler();
}


async function getData(){
	let gmap_data = localStorage.getItem('gmap-data');

	if(gmap_data === null){
		await sleep(500);
		return await getData();
	}

	state.flag = true;
	gmap_data = JSON.parse(gmap_data)
	data = gmap_data;
	state.temp = state.previous;

	return data;
}

async function NextPage() {
	try{
		let next_button = document.querySelector(next_button_tag)
		if (next_button.disabled) {
			return Stop()
		}
	}catch(error){
		return;
	}

	try{
		state.previous_list = document.querySelector(previous_list_tag).innerText
		document.querySelector(next_button_tag).click()
	} catch (error){
		return;
	}

	state.func = leads_parser;
	state.waiter = waiting_for_next_list;
	return await handler();
}


async function info() {

	try{
		let obj = Object()
		let coordinate = await Coordinate()
		let selectors = document.querySelectorAll(infos_selectors_tag)
		let google_location = window.location.href;
		obj.Title = parser(title_tag)
		obj.Subtitle = parser(sub_title_tag)
		obj.Category = parser(category_tag)
		obj.Claim = true

		selectors.forEach((sel) => {
			let innerSelector = sel.querySelector('button')
			if (innerSelector.getAttribute('aria-label') !== null) {
				let infos = sel
					.querySelector('button')
					.getAttribute('aria-label')
					.split(':')
				obj[infos[0]] = infos[1]
			}

			if (innerSelector.innerText !== null) {
				let find_claim = innerSelector.innerText
				if (find_claim.search(/claim/i) !== -1 && obj.Claim === true) {
					obj.Claim = false
				}
			}
		})

		obj.Rating = parser(rating_tag)
		obj.Review_data = reviews_parser();

		var data = {
			search_keyword: Keyword,
			title: obj.Title || null,
			address: obj.Address || null,
			subtitle: obj.Subtitle || null,
			category: obj.Category || null,
			phone: obj.Phone || null,
			latitude: coordinate.Latitude || 0.000000,
			longitude: coordinate.Longitude || 0.000000,
			claim: obj.Claim,
			google_location: google_location,
			searchref: {
				ref_str: state.ref_str || null,
			},
			email: {
				email: obj.Email || null,
			},
			website: {
				title: null,
				domain: obj.Website || null,
			},
			review: {
				total: obj.Review_data.Review || null,
				positive: obj.Review_data.Positive || null,
				negative: obj.Review_data.Negative || null,
				rating: obj.Rating || null,
			},
		}
		state.previous_title = obj.Title
		state.previous_id = state.sub_item_position

		document.querySelector(title_tag).className += ' lead-visible';
		document.getElementById("leadsCount").innerText = state.totalLeads;
		post_data(JSON.stringify(data))
	} catch (error){
		state.sub_item_position++;
		state.func = leads_parser;
		state.waiter = waiter;
		await handler();
		return;
	}

}

let Coordinate = async function () {
	let coordinate = new Object()
	let url = window.location.href
	let co = url.split('@')[1].split('/')[0].split(',')

	coordinate.Latitude = co[0]
	coordinate.Longitude = co[1]

	return coordinate
}

const post_data = function (data) {
	var url = backend_url + '/api/v1/gmap/create/'
	$.ajax({
		url: url,
		type: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		data: data,
		dataType: 'json',
		success: function (res) {
			state.totalLeads = state.totalLeads + 1;
			document.getElementById("leadsCount").innerText = state.totalLeads;
		},
		error: function (err) {
		},
	})

	return 0
}

const error_popup = function (){
	Stop();
	Reset();
	document.querySelector('#ContentBody').style.display = 'none';
	document.querySelector('#ResultBody').style.display = 'none';
	document.querySelector('#leadstalShow').appendChild(server_under_maintenance())
	document.getElementById("m_close").addEventListener("click", CloseBtn)
	document.querySelector('#Unber_maintenance').style.display = 'block';

	return;
}


const save_error = function (message) {
	error_popup()
	var url = backend_url + '/api/v1/gmap/error/create/'
	let data = JSON.stringify({error: message})
	$.ajax({
		url: url,
		type: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		data: data,
		dataType: 'json',
		success: function (res) {
		},
		error: function (err) {
		},
	})

	return;
}

function reviews_parser() {
	try{
		let rating = Object()
		let review = parser(total_review_tag)
		if (review !== null) {
			var rev = review.split(' ')[0]
			rating.Review = parseInt(rev.replaceAll(',', ''))

			let negative_review = negative_review_calculator(rating.Review)
			rating.Positive =
				rating.Review > negative_review
					? rating.Review - negative_review
					: rating.Review
			rating.Negative = negative_review
		} else {
			rating = {
				Review: null,
				Positive: null,
				Negative: null,
			}
		}
		return rating
	} catch (error){

		let rating = Object()
		rating = {
			Review: null,
			Positive: null,
			Negative: null,
		}
		return rating
	}

}

var negative_review_calculator = function (reviews) {
	let selectors = document.querySelectorAll(
		negative_review_calculator_selectors_tag
	)
	let rev = 0
	selectors.forEach((item) => {
		if (
			item.querySelector(negative_review_calculator_item_tag)
				.textContent < 4
		) {
			let persentage = item
				.querySelector(persentage_tag)
				.getAttribute('style')
				.split(':')[1]
				.replace('%', '')
			rev = rev + persentage * (reviews / 100)
		}
	})
	return Math.round(rev)
}

var parser = function (finder) {
	if (document.querySelector(finder) !== null) {
		return document.querySelector(finder).innerText
	}
	return null
}

function timePicker() {
	let sleeper = [
		2000, 2500, 3000, 2200, 2400, 3300, 3500, 4600, 2800, 3700, 4400, 4000,
		4500, 5000,
	]
	let sleepTime = sleeper[Math.floor(Math.random() * sleeper.length)]
	return sleepTime
}

async function waiter(resolver) {

	if (document.querySelector(title_tag) === null) {
		await sleep(1000)
		await waiter(resolver)
	} else {
		await sleep(2000)
		await resolver()
	}
}

async function waiting_for_list(resolver) {
	if (document.querySelector(waiting_for_list_tag) === null) {
		await sleep(1000)
		await waiting_for_list(resolver)
	} else {
		await sleep(2000)
		await resolver()
	}
}

async function waiting_for_next_list(resolver) {
	if (document.querySelector(previous_list_tag).innerText === state.previous_list) {
		await sleep(1000)
		await waiting_for_next_list(resolver)
	} else {
		state.previous_title = ''
		await sleep(2000)
		await resolver()
	}
}

async function waiting_for_next_item(resolver) {
	try{
		if (document.querySelector(title_tag).matches('.lead-visible')) {
			await sleep(1000)
			await waiting_for_next_item(resolver)
		} else {
			await sleep(2000)
			await resolver()
		}
	} catch(error){
		state.sub_item_position++;
		state.func = leads_parser;
		state.waiter = waiter;
		await handler();
	}
}

function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms))
}

function ContentBody() {

	var Inhtml = `
			<div id="ContentBody" class="content_body">
				<div class="leadstal-header">
					<div>
						<span class="header-title">GMap Lead Generator - LeadStal</span>
					</div>
				</div>
				<div class="Body-div">
					<div class="leadstal-logo">
						<img id="icon" class="logo" src="`+ iconURL +`" alt=""></img>
					</div>
					<div class="operation-body">
						<div class="row justify-content-center ">
								<div id="leadstal_play" class="col-4 pr-0" style="display:none">
									<div id="play_btn" class="btn">
										<img class="img" src="`+ play_icon +`" alt=""></img>
									</div>
									<span class="play-text">Resume</span>
								</div>

								<div class="col-4 pr-0" id="leadstal_pause">
									<div id="pause_btn" class="btn">
										<img class="img" src="`+ pause_icon +`" alt=""></img>
										<span class="pause-text">Pause</span>
									</div>
								</div>
								<div class="col-3 pr-0" id="leadstal_stop">
									<div id="stop_btn" class="btn">
										<img class="img" src="`+ stop_icon +`" alt=""></img>
									</div>
									<span class="stop-text">Stop</span>
								</div>
						</div>

						<div class="counter">
							<p id="leadsCounter">Collections: <span id="leadsCount">`+ state.totalLeads +`</span> Leads</p>
						</div>
					</div>
				</div>
				<div class="leadstal-footer">
					⚠️<span class="footer-title">Don't Switch Tabs. Tool Will Stop Working!</span>
				</div>
			</div>
			`;

			var div = document.createElement('div');
			div.innerHTML = Inhtml.trim();

			return div.firstChild;
}


function ResultBody() {

	var Inhtml = `
		<div id="ResultBody" class="result_body" >
			<div class="leadstal-header">
				<div>
					<span class="header-title">GMap Lead Generator - LeadStal</span>
				</div>
				<div style='float: right;'>
					<div class="close-btn" aria-label="Close" id="close">
						<span aria-hidden="true">&times;</span>
					</div>
				</div>
			</div>
			<div class="Body-div">

				<div class="leadstal-logo">
					<img id="icon" class="logo" src="`+ iconURL +`" alt=""></img>
				</div>
				<div class="result-content">
					<h4 class="keyword">`+ Keyword +`</h4>
					<p>Total Leads Collected : `+ state.totalLeads +`</p>
					<a target='_blank' id="leadurl" href="`+ encodeURI(resultUrl) +`" class="btn btn-default">View Result</a>
				</div>
			</div>
			<div class="leadstal-footer"></div>
		</div>
		`;

		var div = document.createElement('div');
		div.innerHTML = Inhtml.trim();

		return div.firstChild;
}


function server_under_maintenance(){
		var Inhtml = `
			<div id="Unber_maintenance" class="result_body" >
				<div class="leadstal-header">
					<div>
						<span class="header-title">GMap Lead Generator - LeadStal</span>
					</div>
					<div style='float: right;'>
						<div class="close-btn" aria-label="Close" id="m_close">
							<span aria-hidden="true">&times;</span>
						</div>
					</div>
				</div>
				<div class="Body-div">
					<h2 class="maintenance_text"> Under Maintenance Try Again Later</h2>
				</div>
				<div class="leadstal-footer"></div>
			</div>
			`;
			var div = document.createElement('div');
			div.innerHTML = Inhtml.trim();

			return div.firstChild;
}


var collection_button = function () {
	try {
		var leadstalButton = document.createElement('div')
		leadstalButton.className = '_leadstal__button'
		leadstalButton.innerHTML = `<img id="icon" class="btn-icon" src="`+ fav_icon +`" alt=""></img> <p class="text">Generate Leads</p>`
		leadstalButton.style.display = 'none'
		document.body.appendChild(leadstalButton)

		var leadstaShow = document.createElement('div')
		leadstaShow.id = 'leadstalShow'
		leadstaShow.className = 'container leadstal-show'
		leadstaShow.style.display = 'none'
		document.body.appendChild(leadstaShow)
		leadstaShow.appendChild(ContentBody())


		var blocker = document.createElement('div')
		blocker.id = 'screenOff'
		blocker.className = 'screen-off'
		leadstaShow.appendChild(blocker)


		document.getElementById("play_btn").addEventListener("click", Play)
		document.getElementById("pause_btn").addEventListener("click", Pause)
		document.getElementById("stop_btn").addEventListener("click", Stop)
		document.querySelector("._leadstal__button").addEventListener("click", Start)
	} catch (error) {
		save_error(JSON.stringify(error, Object.getOwnPropertyNames(error)))
	}
}

// var _gaq = _gaq || [];
// _gaq.push(['_setAccount', 'UA-171790792-2']);
// _gaq.push(['_trackPageview']);

// (function() {
//   var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
//   ga.src = 'https://ssl.google-analytics.com/ga.js';
//   var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
// })();
