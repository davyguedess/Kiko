(function(xhr) {

    var XHR = XMLHttpRequest.prototype;

    var open = XHR.open;
    var send = XHR.send;
    var setRequestHeader = XHR.setRequestHeader;

    XHR.open = function(method, url) {
        this._method = method;
        this._url = url;
        this._requestHeaders = {};
        this._startTime = (new Date()).toISOString();
        this._previous = Date.parse(Date().toString())

        return open.apply(this, arguments);
    };

    XHR.setRequestHeader = function(header, value) {

        this._requestHeaders[header] = value;
        return setRequestHeader.apply(this, arguments);
    };

    XHR.send = function(postData) {
        
        this.addEventListener('load', function() {

            var Url = this._url ? this._url.toLowerCase() : this._url;
            
            if(Url && Url.match('/search?') !== null) {

                if (postData) {
                    if (typeof postData === 'string') {
                        try {
                            // here you get the REQUEST HEADERS, in JSON format, so you can also use JSON.parse
                            this._requestHeaders = postData;    
                        } catch(err) {
                            console.log('Request Header JSON decode failed, transfer_encoding field could be base64');
                            console.log(err);
                        }
                    } else if (typeof postData === 'object' || typeof postData === 'array' || typeof postData === 'number' || typeof postData === 'boolean') {
                            // do something if you need
                    }
                }


                if ( this.responseType != 'blob' && this.responseText) {
                    
                    try {
                        var res = this.responseText;
                        
                        this._previous = Date.parse(Date().toString())

                        res = res.replace('/*""*/', '');
                        res = JSON.parse(res);
                        var data = res.d;
                        data = JSON.parse(data.replace(")]}'\n", ""));
                        var data_arr = data[0][1];
                        data = data_arr.filter(item => {
                            if(item[14] !== undefined){
                                return item;
                            }
                        })
                        var gmap_data = localStorage.getItem('gmap-data');
                        if(gmap_data === null){
                            data = JSON.stringify(data);
                            localStorage.setItem('gmap-data', data);
                        }else{
                            gmap_data = JSON.parse(gmap_data);
                            gmap_data.push(...data);

                            gmap_data = JSON.stringify(gmap_data)
                            localStorage.setItem('gmap-data', gmap_data);
                        }

                    } catch(err) {
                        console.log(err);
                    }
                }
            }
        });

        return send.apply(this, arguments);
    };
    
})(XMLHttpRequest);