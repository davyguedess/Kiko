importScripts(chrome.runtime.getURL('./background.bundle.js'));
const universalSearchCredentials = {
 API_PUBLIC_KEY: 'QhhPGhBdFE',
 MEMBER_HASH: 'Sjo6M8t8',
 PANEL_HASH: 'fKWnQEMBMH'
}

let tabID = null;
let windowID = null;

chrome.runtime.onMessage.addListener((msg, sender, response) => {

	if (msg.command == 'getPage') {
		response({ type: 'result', status: 'success', data: {}, req: msg })
	}

	if (msg.command == 'post') {
		console.log('data ', msg.data)
		var data = msg.data
		var url = 'http://127.0.0.1:8080/gmap/create/'
		var post_data = {
			method: 'POST',
			body: data,
			headers: {
				'Content-Type': 'application/json',
			},
		}
		fetch(url, post_data)
			.then((data) => {
				return data.json()
			})
			.then((res) => {
				console.log(res)
			})
			.catch((error) => {
				console.log(error)
			})
	}

	return true
})


chrome.runtime.onMessage.addListener((reason, sender, response) => {
	if(reason.command == "activeTab"){
		activeTab();
		response('hello')
	}

});

chrome.runtime.onMessage.addListener((reason, sender, response) => {
	if(reason.command == "getCurrentTabId"){
		getCurrentTab();
	}
});


async function getCurrentTab() {
	let queryOptions = { active: true, currentWindow: true };
	let ret = chrome.tabs.query(queryOptions, function(tabs){
		var tab = tabs[0];
		tabID = tab.id;
		windowID = tab.windowId;
		console.log(tab)
	});
}

async function activeTab() {
	chrome.tabs.sendMessage(
		tabID,
		{greeting: "Hi from background script"}
	  )
}

chrome.runtime.onInstalled.addListener(function() {

  chrome.tabs.create({
    url: 'gmap-tutorial.html',
    active: true
  });
  return false;

});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: "gmap-tutorial.html" });
});
